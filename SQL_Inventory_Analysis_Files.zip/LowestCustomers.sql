/**
This is modifying our VIP query to see who our lowest grossing customers are, to see if
we'd like to discontinue the relationship, or see if there is more ways we can do business
with one another.
*//

SELECT o.customerNumber, c.customerName, 
       SUM(quantityOrdered * priceEach) AS gross_sales,
	   SUM(quantityOrdered * (odp.priceEach - odp.buyPrice)) AS gross_profit
  FROM orders o
  JOIN customers c ON o.customerNumber = c.customerNumber
  JOIN (SELECT orderNumber, buyPrice, priceEach, quantityOrdered
		  FROM products p
		  JOIN orderdetails od ON p.productCode = od.productCode) odp
		  ON o.orderNumber = odp.orderNumber		   
 GROUP BY customerName
 ORDER BY gross_profit ASC
 LIMIT 15