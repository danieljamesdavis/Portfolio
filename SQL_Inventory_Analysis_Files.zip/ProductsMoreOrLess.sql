/**
We are interested here in which are our best performing products, and more specifically
we want an answer to the question - "Which products should we order more or less of?"

To determine an answer to this, we want to determine a ranking of product performance
to guide us in the decision of which products we should emphasize or de-emphasize
based on their performance rating.

The first of the performance ratings we are going to choose here is what we will call 
"demand rating" which is the quantity ordered of a particular item divided by the amount
currently in stock. (SUM(ordered)/stockquantity)
We will perform this query on a seperate tab called "DemandRating".

The second one will be the gross sales per product, which is the total sum in dollars
of the sales revenue generated from each item. (SUM(ordered*listprice))

We are going to limit this query to only returning the top 10 highest demand products.

Below we will perform a query that will return a table containing products ranked by these
ratings established above.
**/

SELECT productName, SUM(quantityOrdered) AS total_ordered, buyPrice, 
	   SUM(quantityOrdered*buyPrice) AS gross_sales
  FROM products p
  JOIN orderdetails od ON p.productCode = od.productCode
 GROUP BY productName
 ORDER BY gross_sales DESC
 LIMIT 10