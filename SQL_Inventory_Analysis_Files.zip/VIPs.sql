/**
In order to market most effectively, we'd like to know who our most profitable customers
are, AKA our VIP customers. Our marketing team would like to know who these customers are,
as they may want to plan special events or communications for them in order to continue
with their ongoing business with us, or possibly expand it.

We are going to query our data to find these customers by number, name, and the respective
gross sales and gross profits from our transactions with them.
**/

SELECT o.customerNumber, c.customerName, 
       SUM(quantityOrdered * priceEach) AS gross_sales,
	   SUM(quantityOrdered * (odp.priceEach - odp.buyPrice)) AS gross_profit
  FROM orders o
  JOIN customers c ON o.customerNumber = c.customerNumber
  JOIN (SELECT orderNumber, buyPrice, priceEach, quantityOrdered
		  FROM products p
		  JOIN orderdetails od ON p.productCode = od.productCode) odp
		  ON o.orderNumber = odp.orderNumber		   
 GROUP BY customerName
 ORDER BY gross_profit DESC
 LIMIT 15
 
/**
At a glance, our two easiest candidates for VIP are "Euro+ Shopping Channel" and
"Mini Gifts Distributors Ltd."

These two customers are seperated from the adjacent cluster by several standard 
deviations. The marketing team could add the next few customers if they are looking
for candidates to grow business with.
**/