/**
In this project, we are acting as an analyst at a business who sells vehicles, and we are
performing analysis to help the business on multiple fronts, including sales, marketing,
communications, and operations.

To familiarize ourselves with the data, this first query is to get the number of columns
and rows of each table we are working with in our database.
**/

SELECT "Customers" AS table_name, 13 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM customers

UNION ALL

SELECT "Products" AS table_name, 9 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM products

UNION ALL

SELECT "ProductLines" AS table_name, 4 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM productlines

UNION ALL

SELECT "Orders" AS table_name, 7 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM orders

UNION ALL

SELECT "OrderDetails" AS table_name, 5 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM orderdetails

UNION ALL

SELECT "Payments" AS table_name, 4 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM payments

UNION ALL

SELECT "Employees" AS table_name, 8 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM employees

UNION ALL

SELECT "Offices" AS table_name, 9 AS number_of_attributes, COUNT(*) AS number_of_rows
FROM offices