/**
This is a tab to display the "demand rating" metric calculation mentioned in the
"ProductsMoreOrLess" tab.

We are going to limit this query to only returning the top 10 highest demand products.
**/

SELECT productName, quantityInStock, SUM(quantityOrdered) AS total_ordered, 
       SUM(quantityOrdered)/quantityInStock AS demand_rating
  FROM products p
  JOIN orderdetails od ON p.productCode = od.productCode
 GROUP BY productName
 ORDER BY demand_rating DESC
 LIMIT 10
 
/**
Now we can see what products we'd like to emphasize based on their performances,
and the sales and operations teams can act accordingly.
**/